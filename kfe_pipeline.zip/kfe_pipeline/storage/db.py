import sqlite3, os
from typing import List, Dict, Any, Optional

DDL = """
CREATE TABLE IF NOT EXISTS events (
    provider TEXT,
    event_id TEXT,
    league TEXT,
    home_team TEXT,
    away_team TEXT,
    start_time TEXT,
    PRIMARY KEY (provider, event_id)
);

CREATE TABLE IF NOT EXISTS markets (
    provider TEXT,
    event_id TEXT,
    market TEXT,
    selection TEXT,
    odds REAL,
    implied_prob REAL,
    ts TEXT
);

CREATE TABLE IF NOT EXISTS picks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    provider TEXT,
    event_id TEXT,
    market TEXT,
    selection TEXT,
    projected_prob REAL,
    implied_prob REAL,
    edge REAL,
    confidence REAL,
    tier TEXT,
    placed INTEGER DEFAULT 0,
    result INTEGER DEFAULT NULL -- 1 win, 0 loss, NULL pending
);

CREATE TABLE IF NOT EXISTS results (
    provider TEXT,
    event_id TEXT,
    market TEXT,
    selection TEXT,
    result INTEGER, -- 1 win, 0 loss, -1 void
    ts TEXT
);
"""

def get_conn(path: str) -> sqlite3.Connection:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    conn = sqlite3.connect(path)
    conn.execute("PRAGMA journal_mode=WAL;")
    return conn

def init_db(conn: sqlite3.Connection):
    conn.executescript(DDL)
    conn.commit()

def upsert_event(conn, e: Dict[str, Any]):
    conn.execute(
        """INSERT OR REPLACE INTO events(provider, event_id, league, home_team, away_team, start_time)
        VALUES(?,?,?,?,?,?)""",
        (e["provider"], e["event_id"], e["league"], e["home_team"], e["away_team"], e["start_time"]),
    )

def insert_market(conn, m: Dict[str, Any]):
    conn.execute(
        """INSERT INTO markets(provider, event_id, market, selection, odds, implied_prob, ts)
        VALUES(?,?,?,?,?,?,datetime('now'))""",
        (m["provider"], m["event_id"], m["market"], m["selection"], m["odds"], m["implied_prob"]),
    )

def insert_pick(conn, p: Dict[str, Any]):
    conn.execute(
        """INSERT INTO picks(provider, event_id, market, selection, projected_prob, implied_prob, edge, confidence, tier, placed)
        VALUES(?,?,?,?,?,?,?,?,?,?)""", 
        (p["provider"], p["event_id"], p["market"], p["selection"], p["projected_prob"], p["implied_prob"], p["edge"], p["confidence"], p["tier"], p.get("placed",0))
    )

def list_picks(conn) -> List[Dict[str, Any]]:
    cur = conn.execute("SELECT id, provider, event_id, market, selection, projected_prob, implied_prob, edge, confidence, tier, placed, result FROM picks ORDER BY id DESC")
    cols = [c[0] for c in cur.description]
    return [dict(zip(cols, row)) for row in cur.fetchall()]
