# Gancho simples para ML em ligas difíceis.
# Objetivo: produzir probabilidade para mercados (Over/BTTS/1X2) e servir como peso extra.
from typing import Dict, Any
import numpy as np

class DummyMLModel:
    def __init__(self, seed: int = 42):
        self.rng = np.random.default_rng(seed)

    def predict_proba(self, features: Dict[str, float]) -> float:
        # MOCK: uma combinação simples e ruído
        base = 0.5 * features.get("xg_for", 1.2) / 2.5 + 0.5 * (1.0 - features.get("xg_against", 1.0) / 2.5)
        base = max(0.05, min(0.95, base))
        noise = self.rng.normal(0, 0.03)
        return float(max(0.05, min(0.95, base + noise)))
