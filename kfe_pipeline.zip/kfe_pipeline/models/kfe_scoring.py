from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any
from utils.helpers import clamp, edge

@dataclass
class TeamScores:
    form: float      # 0..1
    attack: float    # 0..1
    strength: float  # 0..1
    tactics: float   # 0..1

    def weighted(self, w: Dict[str, float]) -> float:
        return (
            self.form * w.get("form", 0.3) +
            self.attack * w.get("attack", 0.25) +
            self.strength * w.get("strength", 0.2) +
            self.tactics * w.get("tactics", 0.25)
        )

def apply_context(base_conf: float, league_mult: float, ctx_adj: float, ctx_max: float) -> float:
    ctx_adj = clamp(ctx_adj, -ctx_max, ctx_max)
    final = base_conf * (1.0 + league_mult) + ctx_adj
    return clamp(final, 0.0, 1.0)

def classify_value(projected: float, implied: float, tiers: Dict[str, float]) -> str:
    e = projected - implied
    if e >= tiers.get("bomba", 0.50):
        return "BOMBA"
    if e >= tiers.get("forte", 0.35):
        return "FORTE"
    if e >= tiers.get("standard", 0.25):
        return "STANDARD"
    return "SEM VALOR"
