from __future__ import annotations
import argparse, os, yaml, json, time
from dotenv import load_dotenv
from utils.logging import setup_logger
from utils.helpers import implied_prob_from_decimal_odds, edge, clamp
from providers.odds_api import fetch_upcoming_soccer
from providers.fotmob_scraper import fetch_team_context
from models.kfe_scoring import TeamScores, apply_context, classify_value
from models.ml_model import DummyMLModel
from storage.db import get_conn, init_db, upsert_event, insert_market, insert_pick, list_picks
from tracking.report import report as report_func

logger = setup_logger()

def load_config(path: str) -> dict:
    with open(path, 'r', encoding='utf-8') as f:
        cfg = yaml.safe_load(f)
    return cfg

def synth_scores(team_name: str) -> TeamScores:
    # MOCK: substitua por dados reais (form/attack/strength/tactics normalizados 0-1)
    base = (hash(team_name) % 50) / 100.0 + 0.25
    return TeamScores(
        form=min(1.0, base),
        attack=min(1.0, base + 0.05),
        strength=min(1.0, base + 0.1),
        tactics=min(1.0, base - 0.05 if base>0.3 else base)
    )

def score_match(cfg: dict, league: str, home: str, away: str, league_mult_map: dict, ctx_cfg: dict):
    w = cfg['kfe_weights']
    ts_home = synth_scores(home)
    ts_away = synth_scores(away)
    base_home = ts_home.weighted(w)
    base_away = ts_away.weighted(w)
    base_conf = max(base_home, base_away)

    # Contexto (mock + regras de config)
    ctx_home = fetch_team_context(home)
    ctx_away = fetch_team_context(away)

    ctx_adj = 0.0
    if ctx_home.get('away_pressure'): # se a casa apertada? só exemplo
        ctx_adj += ctx_cfg.get('away_pressure_btts',{}).get('boost',0.0)
    if ctx_away.get('key_player_out'):
        ctx_adj += ctx_cfg.get('key_player_out',{}).get('penalty', -0.07)

    league_mult = league_mult_map.get(league, 0.0)
    final_conf = apply_context(base_conf, league_mult, ctx_adj, ctx_cfg.get('max_adjustment',0.25))

    return {
        "home": home, "away": away,
        "base_home": base_home, "base_away": base_away,
        "final_confidence": final_conf
    }

def suggest_pick(cfg: dict, market: str, projected_prob: float, implied_prob: float) -> dict:
    tiers = cfg['thresholds']['value_tiers']
    tier = classify_value(projected_prob, implied_prob, tiers)
    e = projected_prob - implied_prob
    return {"tier": tier, "edge": e}

def pipeline_run(args):
    load_dotenv()
    cfg = load_config('config.yaml')
    conn = get_conn(cfg['storage']['sqlite_path'])
    init_db(conn)

    region = cfg['general']['region']
    markets = cfg['general']['markets']
    bookmakers = cfg['general']['bookmakers']
    currency = cfg['general']['currency']
    hours_ahead = args.hours_ahead or cfg['general']['hours_ahead_default']

    data = fetch_upcoming_soccer(region, markets, bookmakers, hours_ahead, currency)
    if not data:
        logger.warning("Sem dados da OddsAPI (chave ausente ou quota). Usando modo teste.")
        cfg['general']['test_mode'] = True

    # MOCK dataset se sem dados
    if cfg['general']['test_mode']:
        data = [{
            "id": "mock1",
            "sport_key": "soccer_mock",
            "commence_time": "2025-08-27T19:00:00Z",
            "home_team": "Bayer Leverkusen",
            "away_team": "Hoffenheim",
            "bookmakers": [{
                "title": "bet365",
                "markets": [
                    {"key":"h2h","outcomes":[{"name":"Bayer Leverkusen","price":1.70},{"name":"Hoffenheim","price":4.50},{"name":"Draw","price":4.00}]},
                    {"key":"btts","outcomes":[{"name":"Yes","price":1.65},{"name":"No","price":2.20}]},
                    {"key":"totals","outcomes":[{"name":"Over 2.5","price":1.60},{"name":"Under 2.5","price":2.30}]}
                ]
            }]
        }]

    league_mult = cfg['league_tiers']
    ctx_cfg = cfg['context_factors']

    for ev in data:
        event_id = ev.get('id')
        home = ev.get('home_team','Home')
        away = ev.get('away_team','Away')
        league = ev.get('sport_key','unknown').split('_')[-1]
        start_time = ev.get('commence_time')
        upsert_event(conn, {
            "provider": "oddsapi",
            "event_id": event_id,
            "league": league,
            "home_team": home,
            "away_team": away,
            "start_time": start_time
        })

        # Scoring K.F.E
        scores = score_match(cfg, league, home, away, league_mult, ctx_cfg)
        final_conf = scores['final_confidence']

        # Markets
        for bk in ev.get('bookmakers',[]):
            for m in bk.get('markets',[]):
                key = m.get('key')
                for outcome in m.get('outcomes',[]):
                    sel = outcome.get('name')
                    odds = float(outcome.get('price', 0))
                    impl = implied_prob_from_decimal_odds(odds)
                    insert_market(conn, {
                        "provider":"oddsapi", "event_id":event_id, "market":key, "selection":sel, "odds":odds, "implied_prob":impl
                    })

                    # Exemplo de projeções por mercado (simplificado):
                    if key == "totals" and "Over 2.5" in sel:
                        projected = min(0.95, max(0.05, final_conf))  # projecao bruta
                    elif key == "btts" and sel == "Yes":
                        projected = min(0.95, max(0.05, final_conf * 0.9))
                    elif key == "h2h" and sel == home:
                        projected = min(0.95, max(0.05, final_conf * 0.75))
                    else:
                        projected = min(0.95, max(0.05, final_conf * 0.5))

                    sug = suggest_pick(cfg, key, projected, impl)
                    if sug['tier'] != "SEM VALOR":
                        # Registrar pick candidata
                        from models.kfe_scoring import classify_value
                        conn.execute("BEGIN")
                        insert_pick(conn, {
                            "provider":"oddsapi",
                            "event_id":event_id,
                            "market":key,
                            "selection":sel,
                            "projected_prob":projected,
                            "implied_prob":impl,
                            "edge":sug['edge'],
                            "confidence":final_conf,
                            "tier":sug['tier'],
                            "placed":0
                        })
                        conn.commit()

    logger.info("Pipeline concluído. Picks sugeridas:")
    for p in list_picks(conn)[:10]:
        logger.info(json.dumps(p, ensure_ascii=False))

def pipeline_fetch_odds(args):
    cfg = load_config('config.yaml')
    data = fetch_upcoming_soccer(cfg['general']['region'], cfg['general']['markets'], cfg['general']['bookmakers'], args.hours_ahead or cfg['general']['hours_ahead_default'], cfg['general']['currency'])
    print(json.dumps(data[:1], indent=2, ensure_ascii=False) if data else "Sem dados / verifique sua ODDSAPI_KEY.")

def pipeline_report(args):
    cfg = load_config('config.yaml')
    conn = get_conn(cfg['storage']['sqlite_path'])
    res = report_func(conn, days=args.days or cfg['report']['lookback_days'])
    print(json.dumps(res, indent=2, ensure_ascii=False))
    if 'equity_plot' in res:
        print(f"Equity plot salvo em: {res['equity_plot']}")

def main():
    parser = argparse.ArgumentParser(description="K.F.E v3.3 – Central Pipeline")
    sub = parser.add_subparsers(dest="cmd")

    run_p = sub.add_parser("run", help="Executa pipeline completo")
    run_p.add_argument("--league_codes", type=str, default="eu_all")
    run_p.add_argument("--hours_ahead", type=int, default=None)

    fetch_p = sub.add_parser("fetch-odds", help="Apenas busca odds")
    fetch_p.add_argument("--hours_ahead", type=int, default=None)

    rep_p = sub.add_parser("report", help="Gera relatório")
    rep_p.add_argument("--days", type=int, default=None)

    args = parser.parse_args()
    if args.cmd == "run":
        pipeline_run(args)
    elif args.cmd == "fetch-odds":
        pipeline_fetch_odds(args)
    elif args.cmd == "report":
        pipeline_report(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
