from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Optional
import math

def implied_prob_from_decimal_odds(odds: float) -> float:
    if odds <= 1e-9:
        return 0.0
    return 1.0 / odds

def edge(projected_prob: float, implied_prob: float) -> float:
    # edge como ganho relativo sobre prob implícita
    return max(0.0, projected_prob - implied_prob)

def clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))

def safe_div(a: float, b: float, default: float = 0.0) -> float:
    try:
        return a / b
    except Exception:
        return default

@dataclass
class MatchKey:
    provider: str
    event_id: str

def pct_change(old: float, new: float) -> float:
    if old == 0:
        return 0.0
    return 100.0 * (new - old) / old
