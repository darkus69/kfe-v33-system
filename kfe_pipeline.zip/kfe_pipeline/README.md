# K.F.E v3.3 – Central Pipeline (Odds + xG + Context + Tracking)

Este projeto centraliza:
1) Coleta de **odds** (OddsAPI)
2) Enriquecimento com **xG**/**lesões** (placeholders: FotMob/SportMonks ou scraping opcional)
3) **Scoring K.F.E** + Edge/Value
4) **Tracking** automático em **SQLite** e geração de **relatório**
5) Gancho para **ML** em ligas difíceis (LaLiga/Serie B)

## Requisitos
- Python 3.10+
- `pip install -r requirements.txt`
- Criar um `.env` (copiar de `.env.example`) e preencher `ODDSAPI_KEY`

## Uso rápido
```bash
# 0) Instalar deps
pip install -r requirements.txt

# 1) Configurar variáveis e ligas
cp .env.example .env
# edite .env com sua ODDSAPI_KEY
# edite config.yaml para ajustar ligas, thresholds, pesos etc.

# 2) Pipeline completo (coleta -> score -> sugestões -> tracking -> relatório)
python main.py run --league_codes=eu_all --hours_ahead=48

# 3) Relatório diário/semana
python main.py report --days=7

# 4) Apenas odds
python main.py fetch-odds --league_codes=eu_all --hours_ahead=48
```

## Agendamento
- Linux: `cron` (ex.: a cada dia às 10h).
- Windows: Agendador de Tarefas.
- Alternativa: `systemd` + `timer`.

## Estrutura
```
kfe_pipeline/
├── main.py                # CLI do pipeline
├── config.yaml            # Pesos, ligas, thresholds, ranges de horários
├── requirements.txt
├── .env.example
├── providers/
│   ├── odds_api.py        # Coleta OddsAPI
│   └── fotmob_scraper.py  # Placeholder xG/lesões (implementação opcional)
├── models/
│   ├── kfe_scoring.py     # Implementação K.F.E v3.3
│   └── ml_model.py        # Gancho para ML (ligas difíceis)
├── storage/
│   └── db.py              # SQLite + schemas + CRUD
├── tracking/
│   ├── report.py          # Relatório e métricas
│   └── schema.sql         # DDL da base
└── utils/
    ├── logging.py         # Logging padronizado
    └── helpers.py         # Utilidades (prob implícita, normalizações, etc.)
```

## Observações
- xG/lesões: arquivos `fotmob_scraper.py` trazem esqueleto/documentação para implementação. 
- Você pode plugar APIs pagas (SportMonks/Opta) nos mesmos contratos de função.
- O projeto é opinionated mas modular — mude pesos e thresholds no `config.yaml`.
