from __future__ import annotations
from typing import Dict, Any
import sqlite3, pandas as pd
from tabulate import tabulate
import matplotlib.pyplot as plt

def report(conn: sqlite3.Connection, days: int = 7) -> Dict[str, Any]:
    df = pd.read_sql_query("SELECT * FROM picks ORDER BY id DESC", conn)
    metrics = {}
    if df.empty:
        return {"msg": "Sem picks registradas."}

    df['won'] = df['result'] == 1
    df['lost'] = df['result'] == 0
    df['stake'] = 1.0  # unidade fixa
    df['odds'] = 1.0 / df['implied_prob'].clip(lower=1e-9)
    df['pnl'] = df.apply(lambda r: (r['odds']-1.0)*r['stake'] if r['won'] else (-r['stake'] if r['lost'] else 0.0), axis=1)
    sr = df['won'].mean()
    roi = df['pnl'].sum() / df['stake'].sum()

    metrics.update({
        'n_picks': int(len(df)),
        'hit_rate': float(sr),
        'roi': float(roi),
        'avg_edge': float((df['projected_prob'] - df['implied_prob']).mean())
    })

    # Gráfico simples de equity (cumulativo)
    df['equity'] = df['pnl'].cumsum()
    plt.figure()
    df['equity'].plot(title='Equity Curve (todas as picks)')
    plt.xlabel('Pick #')
    plt.ylabel('Lucro acumulado (unidades)')
    out_png = '/mnt/data/kfe_equity.png'
    plt.savefig(out_png, bbox_inches='tight')
    plt.close()

    # Tabelas
    table = tabulate(df[['market','tier','edge','confidence','pnl']].tail(25), headers='keys', tablefmt='github', floatfmt='.3f')

    return {"metrics": metrics, "equity_plot": out_png, "last_picks": table}
