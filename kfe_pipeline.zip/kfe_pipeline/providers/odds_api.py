from __future__ import annotations
import os, time, requests
from typing import List, Dict, Any, Optional
from urllib.parse import urlencode
from dotenv import load_dotenv
from utils.logging import setup_logger

load_dotenv()
logger = setup_logger("kfe.odds")

ODDSAPI_KEY = os.getenv("ODDSAPI_KEY", "")
ODDSAPI_BASE = os.getenv("ODDSAPI_BASE", "https://api.the-odds-api.com/v4")

def _get(path: str, params: Dict[str, Any]) -> Optional[List[Dict[str, Any]]]:
    if not ODDSAPI_KEY:
        logger.warning("ODDSAPI_KEY vazio. Retornando None.")
        return None
    params["apiKey"] = ODDSAPI_KEY
    url = f"{ODDSAPI_BASE}{path}?{urlencode(params)}"
    logger.info(f"GET {url}")
    r = requests.get(url, timeout=30)
    if r.status_code != 200:
        logger.error(f"Erro OddsAPI {r.status_code}: {r.text}")
        return None
    try:
        data = r.json()
        return data
    except Exception as e:
        logger.exception(f"Falha parse JSON: {e}")
        return None

def fetch_upcoming_soccer(region: str = "eu", markets: str = "h2h,totals,btts", bookmakers: str = "", hours_ahead: int = 48, currency: str = "EUR") -> List[Dict[str, Any]]:
    params = {
        "regions": region,
        "markets": markets,
        "oddsFormat": "decimal",
        "dateFormat": "iso",
        "eventIds": "",
        "includeOpen": "true",
        "bookmakers": bookmakers,
        "currency": currency
    }
    # The Odds API soccer sport key often is 'soccer' sub-keys; here we try generic 'soccer' endpoint for demo.
    # Adjust sport key if needed (e.g., 'soccer_epl', 'soccer_uefa_champs_league', etc.).
    path = "/sports/soccer/odds"
    data = _get(path, params) or []
    # NOTE: Depending on your plan, you may need per-sport endpoints.
    return data
